#!/usr/bin/env bash
# ============================================================================
# 码单器 OTA 发布脚本  ——  8.3.50
# ----------------------------------------------------------------------------
# 用途：把 /workspace/ota 下的三个产物推到 GitHub Pages / Cloudflare Pages，
#       完成网页更新 + OTA 热更新。
#
# 为什么需要本脚本：
#   本沙箱环境只能访问白名单域名（madan.pages.dev 可达），
#   api.github.com / github.com / raw.githubusercontent.com 全部 TLS 握手失败，
#   所以推送必须在你自己能上网的机器上执行本脚本。
#
# 用法：
#   export GITHUB_TOKEN=ghp_xxx        # 你的 token（注意：用完全部权限 token 有风险，
#                                      #   建议改用只勾 repo 的细粒度 token，用完即撤）
#   bash push.sh
#
# 可选环境变量：
#   OWNER=你的GitHub用户名
#   REPO=仓库名
#   BRANCH=分支名
# ============================================================================
set -euo pipefail

OWNER="${OWNER:-srhovo}"
REPO="${REPO:-madan}"
BRANCH="${BRANCH:-main}"
SITE="${SITE:-https://madan.pages.dev}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

red()  { printf '\033[31m%s\033[0m\n' "$*"; }
grn()  { printf '\033[32m%s\033[0m\n' "$*"; }
ylw()  { printf '\033[33m%s\033[0m\n' "$*"; }
die()  { red "✘ $*"; exit 1; }

echo "=================================================="
echo " 码单器 OTA 发布   $OWNER/$REPO @ $BRANCH"
echo "=================================================="
echo

# ---------------------------------------------------------------------------
# 0. token 检查
# ---------------------------------------------------------------------------
if [[ -z "${GITHUB_TOKEN:-}" ]]; then
  die "缺少 GITHUB_TOKEN。先执行： export GITHUB_TOKEN=ghp_xxx"
fi

# ---------------------------------------------------------------------------
# 1. 产物自检（本地，硬性关卡）
# ---------------------------------------------------------------------------
echo "▸ [1/6] 本地产物自检"

[[ -f index.html ]] || die "缺少 index.html"
[[ -f version.json ]] || die "缺少 version.json"
ZIP_NAME="$(python3 -c "import json;print(json.load(open('version.json'))['url'].rsplit('/',1)[-1])")"
[[ -f "$ZIP_NAME" ]] || die "version.json 指向的 $ZIP_NAME 不存在"

# 1a. index.html 必须已是新版本
TITLE="$(grep -o '<title>[^<]*</title>' index.html | head -1)"
APPVER="$(grep -o "APP_VERSION = '[^']*'" index.html | head -1)"
JSONVER="$(python3 -c "import json;print(json.load(open('version.json'))['version'])")"

echo "    <title>       $TITLE"
echo "    APP_VERSION   $APPVER"
echo "    version.json  $JSONVER"
echo "    zip           $ZIP_NAME"

[[ "$TITLE" == *"$JSONVER"* ]]  || die "index.html 的 <title> 与 version.json 版本号不一致（版本双源必须同步）"
[[ "$APPVER" == *"$JSONVER"* ]] || die "index.html 的 APP_VERSION 与 version.json 版本号不一致（版本双源必须同步）"

# 1b. 绝不能带 Cloudflare 注入的埋点（真实线上包不含，是 CF 在分发时注入的）
if grep -q "cloudflareinsights" index.html; then
  red "    检测到 cloudflareinsights 埋点注入！"
  die "index.html 被 Cloudflare 注入污染（应只存在于线上分发产物，仓库源文件不能带）。请先清理。"
fi
grn "    ✓ 无 Cloudflare 注入"

# 1c. zip 内 index.html 与目录下 index.html 必须完全一致
TMPD="$(mktemp -d)"
unzip -q "$ZIP_NAME" -d "$TMPD"
if ! cmp -s "$TMPD/index.html" index.html; then
  rm -rf "$TMPD"
  die "zip 内的 index.html 与目录下 index.html 不一致，请重新打包"
fi
rm -rf "$TMPD"
grn "    ✓ zip 内容与 index.html 一致"

# 1d. checksum 必须与 zip 实际 sha256 一致
LOCAL_SHA="$(sha256sum "$ZIP_NAME" | awk '{print $1}')"
JSON_SHA="$(python3 -c "import json;print(json.load(open('version.json'))['checksum'])")"
echo "    zip sha256    $LOCAL_SHA"
[[ "$LOCAL_SHA" == "$JSON_SHA" ]] || die "version.json 的 checksum 与 zip 实际 sha256 不一致"
grn "    ✓ checksum 匹配"

# ---------------------------------------------------------------------------
# 2. 目标仓库连通性 + 权限
# ---------------------------------------------------------------------------
echo
echo "▸ [2/6] 检查 GitHub 连通性与 token 权限"
API="https://api.github.com/repos/$OWNER/$REPO"
CODE="$(curl -s -o /tmp/_repo.json -w '%{http_code}' \
        -H "Authorization: Bearer $GITHUB_TOKEN" \
        -H "Accept: application/vnd.github+json" \
        "$API" || true)"
echo "    GET $API -> HTTP $CODE"
case "$CODE" in
  200) grn "    ✓ 仓库可访问" ;;
  401) die "token 无效或已过期（HTTP 401）" ;;
  403) die "token 权限不足或被限流（HTTP 403）" ;;
  404) die "仓库不存在，或 token 无权访问该仓库（HTTP 404）" ;;
  *)   die "网络异常（HTTP $CODE）。若为 000，说明当前机器也连不上 GitHub。" ;;
esac
LOGIN="$(python3 -c "import json;d=json.load(open('/tmp/_repo.json'));print(d.get('full_name',''))" 2>/dev/null || echo '')"
PERM="$(python3 -c "import json;d=json.load(open('/tmp/_repo.json'));print(d.get('permissions',{}).get('push'))" 2>/dev/null || echo '')"
echo "    仓库：$LOGIN   push 权限：$PERM"
[[ "$PERM" == "True" ]] || die "token 没有 push 权限"

# ---------------------------------------------------------------------------
# 3. 拉取远端分支（shallow），准备提交
# ---------------------------------------------------------------------------
echo
echo "▸ [3/6] 拉取远端分支"
WORK="$(mktemp -d)"
CLONE_URL="https://x-access-token:${GITHUB_TOKEN}@github.com/${OWNER}/${REPO}.git"
if ! git clone --depth 1 --branch "$BRANCH" "$CLONE_URL" "$WORK/repo" 2>/tmp/_clone.err; then
  red "    git clone 失败："
  sed 's/x-access-token:[^@]*@/x-access-token:***@/g' /tmp/_clone.err | sed 's/^/      /'
  die "无法克隆仓库。请检查分支名是否正确（$BRANCH）、仓库是否为空。"
fi
grn "    ✓ 已克隆到临时目录"

# ---------------------------------------------------------------------------
# 4. 写入产物
# ---------------------------------------------------------------------------
echo
echo "▸ [4/6] 写入产物文件"
cp index.html     "$WORK/repo/index.html"
cp version.json   "$WORK/repo/version.json"
cp "$ZIP_NAME"    "$WORK/repo/$ZIP_NAME"

# 保留历史 zip 供旧客户端回滚？不——旧版本包按原样保留（若仓库里已有就别删）
cd "$WORK/repo"
echo "    仓库根目录当前文件："
ls -1 | sed 's/^/      /'

git config user.name  >/dev/null 2>&1 || true
git config user.email "ota-bot@local" 
git config user.name  "ota-bot"

git add -A
if git diff --cached --quiet; then
  ylw "    没有检测到内容变化（远端已是该版本），跳过提交。"
else
  git commit -m "release: 码单器 8.3.50 (OTA)" \
             -m "修复：个数不落时长行 / 关键词候选全量弹出 / 服务类型误写602 / 点卡片实时更新单价；个数留空默认1。" >/dev/null
  grn "    ✓ 已提交"
fi

# ---------------------------------------------------------------------------
# 5. 推送
# ---------------------------------------------------------------------------
echo
echo "▸ [5/6] 推送到 origin/$BRANCH"
if ! git push origin "HEAD:$BRANCH" 2>/tmp/_push.err; then
  red "    push 失败："
  sed 's/x-access-token:[^@]*@/x-access-token:***@/g' /tmp/_push.err | sed 's/^/      /'
  cd "$SCRIPT_DIR"; rm -rf "$WORK"
  die "推送失败"
fi
grn "    ✓ 已推送"
cd "$SCRIPT_DIR"
rm -rf "$WORK"

# ---------------------------------------------------------------------------
# 6. 线上验收 —— 这一步专治 "看起来成功了其实没更新"
#     Cloudflare Pages 的 SPA fallback 会对任何不存在的路径返回 index.html，
#     即 HTTP 200 + content_type: text/html。所以「curl 返回 200」根本不能
#     证明 zip 存在！必须检查 content_type 是不是 application/zip。
# ---------------------------------------------------------------------------
echo
echo "▸ [6/6] 线上验收（等待 CDN 生效，最多 3 分钟）"

# 6a. version.json
ONLINE_VER=""
for i in $(seq 1 18); do
  ONLINE_VER="$(curl -s --max-time 15 "$SITE/version.json?cb=$(date +%s%N)" \
                | python3 -c "import sys,json;
try:
    print(json.load(sys.stdin).get('version',''))
except Exception:
    print('')" 2>/dev/null || echo '')"
  if [[ "$ONLINE_VER" == "$JSONVER" ]]; then break; fi
  echo "    [$i/18] version.json 仍为 '$ONLINE_VER'，等待…"
  sleep 10
done
if [[ "$ONLINE_VER" != "$JSONVER" ]]; then
  red "    version.json 未更新（线上 '$ONLINE_VER'，期望 '$JSONVER'）"
  die "CDN 未生效或推送未落到发布分支（Cloudflare Pages 监听的分支可能不是 $BRANCH）"
fi
grn "    ✓ version.json = $JSONVER"

# 6b. 线上 index.html 标题
ONLINE_TITLE="$(curl -s --max-time 15 "$SITE/?cb=$(date +%s%N)" | grep -o '<title>[^<]*</title>' | head -1)"
echo "    线上 $ONLINE_TITLE"
[[ "$ONLINE_TITLE" == *"$JSONVER"* ]] || ylw "    ⚠ 标题尚未刷新（CDN 缓存），稍后再看"

# 6c. ★ 关键：验证 zip 真的存在，而不是被 SPA fallback 顶包
echo "    验证 zip 可下载性（关键：必须 content_type=application/zip）"
ZIP_SHA_REMOTE=""
for i in $(seq 1 18); do
  # 只取 header 拿 content_type，再单独下载算 hash
  CT="$(curl -sI --max-time 15 "$SITE/$ZIP_NAME?cb=$(date +%s%N)" \
        | tr -d '\r' | awk -F': ' 'tolower($1)=="content-type"{print $2}' | head -1)"
  if [[ "$CT" == *"application/zip"* || "$CT" == *"octet-stream"* ]]; then
    ZIP_SHA_REMOTE="$(curl -s --max-time 120 "$SITE/$ZIP_NAME?cb=$(date +%s%N)" | sha256sum | awk '{print $1}')"
    break
  fi
  echo "    [$i/18] content-type='$CT'（疑似尚未发布），等待…"
  sleep 10
done

if [[ -z "$ZIP_SHA_REMOTE" ]]; then
  red "    ✘ $ZIP_NAME 在线上不可下载！"
  red "      Cloudflare Pages 对不存在的路径会回落返回 index.html（HTTP 200 + text/html），"
  red "      这会让「curl 返回 200」看起来像成功，实际上 zip 根本没上传。"
  die "zip 未发布成功"
fi

echo "    远端 zip sha256 : $ZIP_SHA_REMOTE"
echo "    本地 zip sha256 : $LOCAL_SHA"
[[ "$ZIP_SHA_REMOTE" == "$LOCAL_SHA" ]] || die "远端 zip 与本地不是同一个文件（内容不一致）"
grn "    ✓ zip 已真实上线且内容一致"

echo
echo "=================================================="
grn " ✔ 发布完成：码单器 $JSONVER"
echo "=================================================="
echo " 网页  ： $SITE/"
echo " 清单  ： $SITE/version.json"
echo " 热更包： $SITE/$ZIP_NAME"
echo
echo "现在用手机打开 app，若本地版本低于 $JSONVER，会拉到热更新。"
echo "（若提示无更新：清一次浏览器缓存，或确认 app 内 UPDATE_MANIFEST_URL 指向 $SITE/version.json）"
echo
ylw "安全提醒：你本次使用的是「全部权限」token，且已在对话中明文出现，"
ylw "        请在 GitHub 设置里立即撤销并重新生成（建议改用仅含 repo 权限的细粒度 token）。"
